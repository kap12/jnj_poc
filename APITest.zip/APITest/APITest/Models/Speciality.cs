﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APITest.Models
{
    public class Speciality
    {
        public string name { get; set; }
        public string tid { get; set; }
        public string uuid { get; set; }
        public string parent_target_id { get; set; }
    }
}