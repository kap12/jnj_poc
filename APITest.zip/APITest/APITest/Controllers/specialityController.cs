﻿using APITest.Models;
using Newtonsoft.Json;

using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

using System.Web.Mvc;

namespace APITest.Controllers
{
    public class specialityController : Controller
    {
        // GET: speciality
        string baseUrl = "https://stage.locator.jnjmedicaldevices.com/";

        public async Task<ActionResult> Index()
        {
            List<Speciality> spec = new List<Speciality>();
            using (var client = new HttpClient())
            {
                var url = baseUrl;
                var uri = new Uri(url);

                client.BaseAddress = new Uri(baseUrl);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var csrf_token = "f8302dcIhY_7VIYkAYAp1Uo5nB7UmIrlWrSwDE69vfY";
                client.DefaultRequestHeaders.Add("Cookie", csrf_token);
                //HttpClientHandler handler = new HttpClintHandler();
                //handler.CookieContainer = new CookieContainer();
                //handler.CookieContainer.Add(uri, new Cookie("Cookie", csrf_token)); // Adding a Cookie
                //var client1 = new HttpClient(handler);


                //client.DefaultRequestHeaders.Add("Cookie", "NO_CACHE=1; SSESSac24db5b25cae900caf775a5b54bfb82=VAqNa75zWMYR-WJ9c3ArGAWQ4ve-JxVJ9pRroeH8JGsAFUg6; SimpleSAMLSessionID=f099d7d739e86b4d179d67a93c431130");
                HttpResponseMessage res = await client.GetAsync("api/locator/specialties");

                if (res.IsSuccessStatusCode)
                {
                    var specRes = res.Content.ReadAsStringAsync().Result;
                    spec = JsonConvert.DeserializeObject<List<Speciality>>(specRes);

                }
            }
                return View(spec);
        }
    }
}