﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace APITest.Controllers
{
    public class Login : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }
    }
}