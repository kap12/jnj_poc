using System;

public class Class1
    {
    static public void Main(String[] args)
    {
            var client = new RestClient("https://jsonplaceholder.typicode.com/posts");
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddHeader("Content-Type", "application/json");
            var body = @"{""title"":""testdata"",""body"":""testdata"",""userID"":""50""}";
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            IRestResponse response = client.Execute(request);
            Console.WriteLine(response.Content);
        }
    }
