/* SystemJS module definition */
/* eslint-disable no-var */
declare var module: NodeModule;
interface NodeModule {
  id: string;
}
