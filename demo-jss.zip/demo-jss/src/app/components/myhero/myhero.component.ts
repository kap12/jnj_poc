import { Component, OnInit, Input } from '@angular/core';
import { ComponentRendering } from '@sitecore-jss/sitecore-jss-angular';

@Component({
  selector: 'app-myhero',
  templateUrl: './myhero.component.html',
  styleUrls: ['./myhero.component.css']
})
export class MyheroComponent implements OnInit {
  @Input() rendering: ComponentRendering;

  constructor() { }

  ngOnInit() {
    // remove this after implementation is done
    console.log('myhero component initialized with component data', this.rendering);
  }
}
