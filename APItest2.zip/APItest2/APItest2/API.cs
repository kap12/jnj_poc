﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Threading.Tasks;

namespace WebApplication1
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string strurltest = String.Format("https://stage.locator.jnjmedicaldevices.com/user/login");
            WebRequest requestObjPost = WebRequest.Create(strurltest);
            requestObjPost.Credentials = new NetworkCredential("sitecore-poc", "E=4N=eRDms&v%Ahv");
            requestObjPost.Method = "POST";
            requestObjPost.ContentType = "application/json";
            //HttpWebResponse responseObjPost = null;
            //responseObjPost = (HttpWebResponse)requestObjPost.GetResponse();

            //string strresulttest = null;
            string postData = "";

            using (var streamWriter = new StreamWriter(requestObjPost.GetRequestStream()))
            {
                streamWriter.Write(postData);
                streamWriter.Flush();
                streamWriter.Close();

                var httpResponse = requestObjPost.GetResponse();

                using (var streamReader = new StreamReader(requestObjPost.GetRequestStream()))
                {
                    var result2 = streamReader.ReadToEnd();

                }
            }
        }
    }
}